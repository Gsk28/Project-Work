/*
 * (C) 2025, Cornell University
 * All rights reserved.
 *
 * Description: kernel ≈ 2 handlers
 * intr_entry() handles timer and device interrupts.
 * excp_entry() handles system calls and faults (e.g., invalid memory access).
 */

#include <string.h>
#include "process.h"

// --- Student Added Prototypes ---
void mlfq_update_level(struct process *p);
void mlfq_reset_level();
extern struct process proc_set[MAX_NPROCESS + 1];
// --------------------------------

uint core_in_kernel;
uint core_to_proc_idx[NCORES];
struct process proc_set[MAX_NPROCESS + 1];
/* proc_set[0] is a place holder for idle cores. */

#define curr_proc_idx core_to_proc_idx[core_in_kernel]
#define curr_pid      proc_set[curr_proc_idx].pid
#define curr_status   proc_set[curr_proc_idx].status
#define curr_saved    proc_set[curr_proc_idx].saved_registers

static void intr_entry(uint);
static void excp_entry(uint);

void kernel_entry() {
    asm("csrr %0, mhartid" : "=r"(core_in_kernel));
    asm("csrr %0, mepc" : "=r"(proc_set[curr_proc_idx].mepc));
    memcpy(curr_saved, SAVED_REGISTER_ADDR, SAVED_REGISTER_SIZE);

    uint mcause;
    asm("csrr %0, mcause" : "=r"(mcause));
    (mcause & (1 << 31)) ? intr_entry(mcause & 0x3FF) : excp_entry(mcause);

    asm("csrw mepc, %0" ::"r"(proc_set[curr_proc_idx].mepc));
    memcpy(SAVED_REGISTER_ADDR, curr_saved, SAVED_REGISTER_SIZE);
}

#define INTR_ID_TIMER   7
#define EXCP_ID_ECALL_U 8
#define EXCP_ID_ECALL_M 11
static void proc_yield();
static void proc_try_syscall(struct process* proc);

static void excp_entry(uint id) {
    if (id >= EXCP_ID_ECALL_U && id <= EXCP_ID_ECALL_M) {
        uint syscall_paddr = earth->mmu_translate(curr_pid, SYSCALL_ARG);
        memcpy(&proc_set[curr_proc_idx].syscall, (void*)syscall_paddr,
               sizeof(struct syscall));
        proc_set[curr_proc_idx].syscall.status = PENDING;

        proc_set_pending(curr_pid);
        proc_set[curr_proc_idx].mepc += 4;
        proc_try_syscall(&proc_set[curr_proc_idx]);
        proc_yield();
        return;
    }
    FATAL("excp_entry: kernel got exception %d", id);
}

static void intr_entry(uint id) {
    /* --- DEBUGGING START --- */
    if (id == INTR_ID_TIMER && curr_proc_idx != 0) {
        // Check if index is valid before writing
        if (curr_proc_idx > MAX_NPROCESS) {
            printf("[FATAL] Timer Interrupt: Invalid Index %d\n", curr_proc_idx);
            while(1); // Freeze here so we can see the message
        }
        
        // Attempt the write
        proc_set[curr_proc_idx].cpu_time++;
        proc_set[curr_proc_idx].interrupt_count++;
        proc_set[curr_proc_idx].ticks_in_level++;
        
        if (proc_set[curr_proc_idx].first_scheduled_time == -1) {
             proc_set[curr_proc_idx].first_scheduled_time = proc_set[curr_proc_idx].cpu_time; 
        }
    }
    /* --- DEBUGGING END --- */

    if (id != INTR_ID_TIMER) FATAL("excp_entry: kernel got interrupt %d", id);
    proc_yield();
}

static int boost_timer = 0;

static void proc_yield() {
    /* 1. Update MLFQ Level for current process (Rule 4) */
    struct process *curr = &proc_set[curr_proc_idx];
    if (curr->status == PROC_RUNNING) {
        mlfq_update_level(curr);
        curr->status = PROC_RUNNABLE;
    }

    /* 2. Check for Priority Boost (Rule 5) */
    boost_timer++;
    if (boost_timer >= 1000) { 
        mlfq_reset_level();
        boost_timer = 0;
    }

    /* 3. Find the highest priority process (Rule 1 & 3) */
    int next_idx = -1;
    int best_level = 6; // Worse than lowest priority (4)

    // ROUND ROBIN LOOP: Start search from (curr + 1)
    for (uint i = 1; i <= MAX_NPROCESS; i++) {
         int check_idx = (curr_proc_idx + i) % (MAX_NPROCESS + 1);
         if (check_idx == 0) continue; 

         struct process *p = &proc_set[check_idx];

         // Handle Pending Syscalls
         if (p->status == PROC_PENDING_SYSCALL) proc_try_syscall(p);

         if (p->status == PROC_RUNNABLE || p->status == PROC_READY) {
             // STRICT PRIORITY: Update only if we find a strictly better level
             if (p->priority_level < best_level) {
                 best_level = p->priority_level;
                 next_idx = check_idx;
             }
             // TIE BREAKING: If equal, keep the first one found (Round Robin)
             else if (p->priority_level == best_level && next_idx == -1) {
                 next_idx = check_idx;
             }
         }
    }

    if (next_idx == -1) next_idx = 0;

    /* 4. Switch Context */
    curr_proc_idx = next_idx;

    earth->mmu_switch(curr_pid);
    earth->mmu_flush_cache();

    if (proc_set[curr_proc_idx].status == PROC_READY) {
        curr_saved[0]                = APPS_ARG;
        curr_saved[1]                = APPS_ARG + 4;
        proc_set[curr_proc_idx].mepc = APPS_ENTRY;
    }

    proc_set_running(curr_pid);
    earth->timer_reset(core_in_kernel);
}

static void proc_try_send(struct process* sender) {
    for (uint i = 0; i < MAX_NPROCESS; i++) {
        struct process* dst = &proc_set[i];
        if (dst->pid == sender->syscall.receiver &&
            dst->status != PROC_UNUSED) {
            if (!(dst->syscall.type == SYS_RECV &&
                  dst->syscall.status == PENDING))
                return;
            if (!(dst->syscall.sender == GPID_ALL ||
                  dst->syscall.sender == sender->pid))
                return;

            dst->syscall.status = DONE;
            dst->syscall.sender = sender->pid;
            memcpy(dst->syscall.content, sender->syscall.content,
                   SYSCALL_MSG_LEN);
            return;
        }
    }
    FATAL("proc_try_send: unknown receiver pid=%d", sender->syscall.receiver);
}

static void proc_try_recv(struct process* receiver) {
    if (receiver->syscall.status == PENDING) return;

    uint syscall_paddr = earth->mmu_translate(receiver->pid, SYSCALL_ARG);
    memcpy((void*)syscall_paddr, &receiver->syscall, sizeof(struct syscall));

    proc_set_runnable(receiver->pid);
    proc_set_runnable(receiver->syscall.sender);

    /* --- DEBUGGING START --- */
    // We suspect this block is causing the crash.
    if (receiver->pid == GPID_SHELL) {
        // 1. Print the address we are about to write to
        printf("[DEBUG] Shell Boost Triggered.\n");
        printf("[DEBUG] Receiver PID: %d (Expected %d)\n", receiver->pid, GPID_SHELL);
        printf("[DEBUG] Receiver Struct Address: %x\n", (unsigned int)receiver);

        // 2. Attempt the write
        receiver->priority_level = 0;
        receiver->ticks_in_level = 0;
        
        printf("[DEBUG] Shell Boost Successful.\n");
    }
    /* --- DEBUGGING END --- */
}

static void proc_try_syscall(struct process* proc) {
    switch (proc->syscall.type) {
    case SYS_RECV:
        proc_try_recv(proc);
        break;
    case SYS_SEND:
        proc_try_send(proc);
        break;
    default:
        FATAL("proc_try_syscall: unknown syscall type=%d", proc->syscall.type);
    }
}
