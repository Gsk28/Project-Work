/*
 * (C) 2025, Cornell University
 * All rights reserved.
 *
 * Description: helper functions for process management
 */

#include "process.h"

// Use the existing MAX_NPROCESS from headers
extern struct process proc_set[MAX_NPROCESS + 1];

// --- MLFQ Helper Functions (Placed Correctly) ---

// Rule 2: Level i runs for (i+1)*100 ms.
// Assuming 1 tick = 10ms, so 100ms = 10 ticks.
void mlfq_update_level(struct process *p) {
    // Calculate max ticks allowed for current level
    int time_limit = (p->priority_level + 1) * 10; 

    if (p->ticks_in_level >= time_limit) {
        if (p->priority_level < 4) { // Max level is 4
            p->priority_level++;
            p->ticks_in_level = 0; // Reset ticks for the new level
        }
    }
}

// Rule 5: Reset all to level 0
void mlfq_reset_level() {
    for (uint i = 1; i <= MAX_NPROCESS; i++) {
        if (proc_set[i].status != PROC_UNUSED) {
            proc_set[i].priority_level = 0;
            proc_set[i].ticks_in_level = 0;
        }
    }
    printf("MLFQ: Priority Boost!\n");
}
// -----------------------------------------------

static void proc_set_status(int pid, enum proc_status status) {
    for (uint i = 0; i < MAX_NPROCESS; i++)
        if (proc_set[i].pid == pid) proc_set[i].status = status;
}

void proc_set_ready(int pid) { proc_set_status(pid, PROC_READY); }
void proc_set_running(int pid) { proc_set_status(pid, PROC_RUNNING); }
void proc_set_runnable(int pid) { proc_set_status(pid, PROC_RUNNABLE); }
void proc_set_pending(int pid) { proc_set_status(pid, PROC_PENDING_SYSCALL); }

int proc_alloc() {
    static uint curr_pid = 0;
    for (uint i = 1; i <= MAX_NPROCESS; i++)
        if (proc_set[i].status == PROC_UNUSED) {
            proc_set[i].pid    = ++curr_pid;
            proc_set[i].status = PROC_LOADING;

            // --- Initialize MLFQ Fields ---
            proc_set[i].priority_level = 0;  // Start at Level 0
            proc_set[i].ticks_in_level = 0;
            proc_set[i].cpu_time = 0;
            proc_set[i].interrupt_count = 0;
            // ------------------------------
            
            return curr_pid;
        }

    FATAL("proc_alloc: reach the limit of %d processes", MAX_NPROCESS);
}

void proc_free(int pid) {
    /* Student's code goes here (Preemptive Scheduler). */

    // Find the index of the process to print stats correctly
    int idx = -1;
    for (uint i = 0; i < MAX_NPROCESS; i++) {
        if (proc_set[i].pid == pid) {
            idx = i;
            break;
        }
    }

    if (idx != -1) {
        printf("Process %d Terminated:\n", pid);
        printf("  CPU Time: %d ticks\n", proc_set[idx].cpu_time);
        printf("  Interrupts: %d\n", proc_set[idx].interrupt_count);
    }

    /* End of stats printing */

    if (pid != GPID_ALL) {
        earth->mmu_free(pid);
        proc_set_status(pid, PROC_UNUSED);
    } else {
        /* Free all user processes. */
        for (uint i = 0; i < MAX_NPROCESS; i++)
            if (proc_set[i].pid >= GPID_USER_START &&
                proc_set[i].status != PROC_UNUSED) {
                earth->mmu_free(proc_set[i].pid);
                proc_set[i].status = PROC_UNUSED;
            }
    }
    /* Student's code ends here. */
}

void proc_sleep(int pid, uint usec) {
    /* Student's code goes here (System Call & Protection). */
    /* Update the sleep-related fields in the struct process for process pid. */

    /* Student's code ends here. */
}

void proc_coresinfo() {
    /* Student's code goes here (Multicore & Locks). */
    /* Print out the pid of the process running on each CPU core. */
    /* Student's code ends here. */
}
