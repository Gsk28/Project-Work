#include "app.h"
#include <string.h>

#define LINE_BUF_SIZE 1024

int main(int argc, char *argv[]) {
    if (argc != 3) {
        printf("Usage: grep [PATTERN] [FILE]\n");
        return 0;
    }

    char *pattern = argv[1];
    char *filename = argv[2];
    char buf[BLOCK_SIZE];       // Buffer for file_read
    char line[LINE_BUF_SIZE];   // Buffer to construct lines
    int line_pos = 0;

    // 1. Get Inode
    int ino = dir_lookup(workdir_ino, filename);
    if (ino < 0) {
        printf("grep: cannot open %s\n", filename);
        return 0;
    }

    // 2. Read Loop
    int offset = 0;
    while (1) {
        // Read one block from the file
        int len = file_read(ino, offset, buf);
        if (len <= 0) break; // End of file or error

        // Process characters in this block
        for (int i = 0; i < len; i++) {
            char c = buf[i];

            // If newline, we have a complete line to check
            if (c == '\n') {
                line[line_pos] = '\0'; // Null-terminate the string
                
                // Check if pattern exists in line
                if (strstr(line, pattern) != NULL) {
                    printf("%s\n", line);
                }
                
                // Reset line buffer for the next line
                line_pos = 0;
            } else {
                // Otherwise, keep building the line
                if (line_pos < LINE_BUF_SIZE - 1) {
                    line[line_pos++] = c;
                }
            }
        }
        
        // Move offset for next read
        offset += BLOCK_SIZE;
    }

    return 0;
}
